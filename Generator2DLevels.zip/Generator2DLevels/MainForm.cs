namespace Generator2DLevels;
//<a href="https://www.flaticon.com/ru/free-icons/" title=" иконки"> иконки от Freepik - Flaticon</a>
public partial class MainForm : Form
{
    public static Panel PMain = new Panel
    {
        Size = new Size(1920, 1000)
    };
    public static Panel PGridPanels = new Panel
    {
        Size = new Size(1400, 980),
        Location = new Point(width / 2 - 700, 20),
        BackColor = Color.Black,
        AutoScroll = true
    };
    public static int TY = 0, TX = 0;
    public MainForm()
    {
        InitializeComponent();
        Controls.Add(PMain);
        PMain.Controls.Add(PGridPanels);

        Button BCreate = new Button
        {
            Size = new Size(200, 40),
            BackColor = Color.CadetBlue,
            Text = "Сгенерировать",
            Location = new Point(width - 230, heigth - 60),
            FlatStyle = FlatStyle.Popup,
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
            ForeColor = Color.White,
        };
        PMain.Controls.Add(BCreate);

        PictureBox PiEraser = new PictureBox
        {
            Size = new Size(40, 40),
            BackColor = Color.Transparent,
            Location = new Point(width - 210, heigth / 2 - 135),
            Image = Image.FromFile("resousers/image/El_eraserOFF.png"),
            SizeMode = PictureBoxSizeMode.Zoom
        };
        PMain.Controls.Add(PiEraser);
        PiEraser.Click += (a, e) =>
        {
            ClickBoolEraser = !ClickBoolEraser ? true : false;
            if (ClickBoolEraser)
            {
                PiEraser.Size = new Size(30, 30);
                PiEraser.Location = new Point(width - 205, heigth / 2 - 130);
                PiEraser.Image = Image.FromFile("resousers/image/El_eraserON.png");
            }
            else
            {
                PiEraser.Size = new Size(40, 40);
                PiEraser.Location = new Point(width - 210, heigth / 2 - 135);
                PiEraser.Image = Image.FromFile("resousers/image/El_eraserOFF.png");
            }
        };

        Button BSave = new Button
        {
            Size = new Size(200, 40),
            BackColor = Color.CadetBlue,
            Text = "Сохранить",
            Location = new Point(width - 230, heigth - 110),
            FlatStyle = FlatStyle.Popup,
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
            ForeColor = Color.White
        };
        PMain.Controls.Add(BSave);

        Button BCheckFullNet = new Button
        {
            Size = new Size(20, 20),
            BackColor = Color.Chartreuse,
            Location = new Point(width - 230, heigth / 2 - 80),
            FlatStyle = FlatStyle.Popup,
        };
        PMain.Controls.Add(BCheckFullNet);
        BCheckFullNet.Click += (a, e) =>
        {
            ClickBoolNet = !ClickBoolNet ? true : false;
            if (!ClickBoolNet)
            {
                foreach (Label label in PGridPanels.Controls.OfType<Label>())
                {
                    label.BorderStyle = BorderStyle.None;
                }
                BCheckFullNet.BackColor = Color.DarkGray;
            }
            else
            {
                foreach (Label label in PGridPanels.Controls.OfType<Label>())
                {
                    label.BorderStyle = BorderStyle.FixedSingle;
                }
                BCheckFullNet.BackColor = Color.Chartreuse;
            }
        };

        TextBox TIdPanel = new TextBox
        {
            Size = new Size(200, 40),
            BackColor = Color.Gray,
            Location = new Point(width - 230, 50),
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
        };
        PMain.Controls.Add(TIdPanel);

        TextBox TXCountPanel = new TextBox
        {
            Size = new Size(200, 40),
            BackColor = Color.Gray,
            Location = new Point(width - 230, 120),
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
        };
        PMain.Controls.Add(TXCountPanel);

        TextBox TYCountPanel = new TextBox
        {
            Size = new Size(200, 40),
            BackColor = Color.Gray,
            Location = new Point(width - 230, 190),
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
        };
        PMain.Controls.Add(TYCountPanel);

        Label LTextPanel = new Label
        {
            AutoSize = true,
            Text = "Панель",
            Location = new Point(width / 2 - 40, 0),
            FlatStyle = FlatStyle.Popup,
            Font = new Font("Comic Sans MS", 12, FontStyle.Bold),
            ForeColor = Color.White,
        };
        PMain.Controls.Add(LTextPanel);

        Label LTextInfo = new Label
        {
            AutoSize = true,
            Text = "Номер ячейки\n\n\nКоличество по длине\n\n\nКоличество по высоте\n\n\nЯчейки цветов\n\n\n\nВыбран цвет\n\n\n\n   Сетка",
            Location = new Point(width - 230, 25),
            FlatStyle = FlatStyle.Popup,
            Font = new Font("Comic Sans MS", 12, FontStyle.Bold),
            ForeColor = Color.White,
        };
        PMain.Controls.Add(LTextInfo);

        Label LTextCoords = new Label
        {
            AutoSize = true,
            Text = "Координаты (x,y): ",
            Location = new Point(5, 5),
            Font = new Font("Comic Sans MS", 12, FontStyle.Bold),
            ForeColor = Color.White,
        };
        PMain.Controls.Add(LTextCoords);

        Label LPanelsColor = new Label()
        {
            Size = new Size(50, 50),
            BackColor = Color.White,
            Location = new Point(width - 155, heigth / 2 - 140),
        };
        PMain.Controls.Add(LPanelsColor);
        LPanelsColor.BringToFront();

        int corX = 0, corY = 0;
        string[] strColors = [];
        if (File.Exists("resousers/fileColors.txt"))
        {
            strColors = File.ReadAllText("resousers/fileColors.txt").Split("*");
        }
        for (short i = 0; i < 14; i++)
        {
            Label button = new Label()
            {
                Name = "COLOR",
                Size = new Size(30, 30),
                Location = new Point(width - corX - 55, heigth / 2 - corY - 210),
                Font = new Font("", 9),
                BorderStyle = BorderStyle.FixedSingle
            };
            if (strColors.Length > 1) button.BackColor = Color.FromArgb(Convert.ToInt32(strColors[i]));
            else button.BackColor = Color.White;
            button.MouseClick += (a, e) =>
            {
                if (e.Button == MouseButtons.Right)
                {
                    ColorDialog colorDialog = new ColorDialog();
                    colorDialog.Color = Color.White;
                    colorDialog.FullOpen = true;
                    if (colorDialog.ShowDialog() == DialogResult.Cancel) button.BackColor = Color.White;
                    else button.BackColor = colorDialog.Color;
                }
                LPanelsColor.BackColor = button.BackColor;
            };
            PMain.Controls.Add(button);
            button.BringToFront();

            corX += 30;
            if (i == 6)
            {
                corX = 0;
                corY += 30;
            }
        }

        BCreate.Click += (a, e) =>
        {
            try
            {
                if (TXCountPanel.Text.Length > 0 && TYCountPanel.Text.Length > 0)
                {
                    if (int.TryParse(TXCountPanel.Text, out int _) && int.TryParse(TYCountPanel.Text, out int _))
                    {
                        DialogResult dialog = default;
                        if (PGridPanels.Controls.Count > 0) dialog = MessageBox.Show("Вы действительно хотите пересгенирироваить панель?\nПредыдущие данные не сохранятся!", "Предупреждение!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (dialog == DialogResult.Yes || PGridPanels.Controls.Count == 0)
                        {
                            LTextCoords.Text = "Координаты (x,y): ";
                            PGridPanels.Controls.Clear();
                            TX = Convert.ToInt32(TXCountPanel.Text);
                            TY = Convert.ToInt32(TYCountPanel.Text);
                            int corX = 0, corY = 0;
                            if (TX <= 256 && TY <= 256 && TX > 0 && TY > 0)
                            {
                                for (short i = 0; i < TX * TY; i++)
                                {
                                    Label button = new Label()
                                    {
                                        Name = $"{corX / 30} / {corY / 30}",
                                        Size = new Size(30, 30),
                                        BackColor = Color.White,
                                        Location = new Point(corX,corY),
                                        Font = new Font("", 9),
                                    };
                                    if (ClickBoolNet) button.BorderStyle = BorderStyle.FixedSingle;
                                    else button.BorderStyle = BorderStyle.None;
                                    button.MouseClick += (a, e) =>
                                    {
                                        if (e.Button == MouseButtons.Left)
                                        {
                                            if (!ClickBoolEraser)
                                            {
                                                button.Text = TIdPanel.Text;
                                                button.BackColor = LPanelsColor.BackColor;
                                            }
                                            else
                                            {
                                                button.Text = default;
                                                button.BackColor = Color.White;
                                            }
                                        }
                                        else if (e.Button == MouseButtons.Right) ClickBoolColor = ClickBoolColor == false ? true : false;
                                    };
                                    button.MouseMove += (a, e) =>
                                    {
                                        if (ClickBoolColor == true)
                                        {
                                            if (!ClickBoolEraser)
                                            {
                                                button.Text = TIdPanel.Text;
                                                button.BackColor = LPanelsColor.BackColor;
                                            }
                                            else
                                            {
                                                button.Text = default;
                                                button.BackColor = Color.White;
                                            }
                                        }
                                        LTextCoords.Text = "Координаты (x,y): " + button.Name;
                                    };
                                    PGridPanels.Controls.Add(button);

                                    corX += 30;
                                    if (TX * 30 == corX)
                                    {
                                        corX = 0;
                                        corY += 30;
                                    }
                                }
                            }
                        }
                        else MessageBox.Show("Поля длины и ширины должны быть меньше 256 ячеек\nи больше 0!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else MessageBox.Show("Поля длины и ширины должны содержать только цифры!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else MessageBox.Show("Поля длины и ширины должны быть заполнены!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Что-то пошло не так!\n\n{ex.Message}", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        };

        BSave.Click += (a, e) =>
        {
            if (PGridPanels.Controls.Count > 0)
            {
                FormCreateLevel.Open();
            }
            else MessageBox.Show("Сначала вы должны сгенерировать ячейки!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        };
    }
}