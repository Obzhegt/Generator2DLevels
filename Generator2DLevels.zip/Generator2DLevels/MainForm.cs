namespace Generator2DLevels;
//<a href="https://www.flaticon.com/free-icons/electric-generator" title="electric generator icons">Electric generator icons created by smashingstocks - Flaticon</a>
public partial class MainForm : Form
{
    public static Panel PMain = new Panel
    {
        Size = new Size(1000, 600)
    };
    public static int TY = 0, TX = 0;
    public MainForm()
    {
        InitializeComponent();
        Controls.Add(PMain);

        Panel PGridPanels = new Panel
        {
            Size = new Size(570, 570),
            Location = new Point(10, 20),
            BackColor = Color.Black,
            AutoScroll = true
        };
        PMain.Controls.Add(PGridPanels);

        Button BCreate = new Button
        {
            Size = new Size(200, 40),
            BackColor = Color.CadetBlue,
            Text = "Сгенерировать",
            Location = new Point(width - 220, heigth - 60),
            FlatStyle = FlatStyle.Popup,
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
            ForeColor = Color.White,
        };
        PMain.Controls.Add(BCreate);

        Button BSave = new Button
        {
            Size = new Size(200, 40),
            BackColor = Color.CadetBlue,
            Text = "Сохранить",
            Location = new Point(width - 220, heigth - 110),
            FlatStyle = FlatStyle.Popup,
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
            ForeColor = Color.White
        };
        PMain.Controls.Add(BSave);

        TextBox TIdPanel = new TextBox
        {
            Size = new Size(200, 40),
            BackColor = Color.Gray,
            Location = new Point(width - 220, 50),
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
        };
        PMain.Controls.Add(TIdPanel);

        TextBox TXCountPanel = new TextBox
        {
            Size = new Size(200, 40),
            BackColor = Color.Gray,
            Location = new Point(width - 220, 120),
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
        };
        PMain.Controls.Add(TXCountPanel);

        TextBox TYCountPanel = new TextBox
        {
            Size = new Size(200, 40),
            BackColor = Color.Gray,
            Location = new Point(width - 220, 190),
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
        };
        PMain.Controls.Add(TYCountPanel);

        Label LTextPanel = new Label
        {
            AutoSize = true,
            Text = "Панель",
            Location = new Point(260, 0),
            FlatStyle = FlatStyle.Popup,
            Font = new Font("Comic Sans MS", 12, FontStyle.Bold),
            ForeColor = Color.White,
        };
        PMain.Controls.Add(LTextPanel);

        Label LTextInfo = new Label
        {
            AutoSize = true,
            Text = "Номер ячейки\n\n\nКоличество по длине\n\n\nКоличество по высоте",
            Location = new Point(width - 220, 25),
            FlatStyle = FlatStyle.Popup,
            Font = new Font("Comic Sans MS", 12, FontStyle.Bold),
            ForeColor = Color.White,
        };
        PMain.Controls.Add(LTextInfo);

        BCreate.Click += (a, e) =>
        {
            try
            {
                if (TXCountPanel.Text.Length > 0 && TYCountPanel.Text.Length > 0)
                {
                    if (int.TryParse(TXCountPanel.Text, out int _) && int.TryParse(TYCountPanel.Text, out int _))
                    {
                        DialogResult dialog = default;
                        if (PGridPanels.Controls.Count > 0) dialog = MessageBox.Show("Вы действительно хотите пересгенирироваить панель?\nПредыдущие данные не сохранятся!", "Предупреждение!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (dialog == DialogResult.Yes || PGridPanels.Controls.Count == 0)
                        {
                            PGridPanels.Controls.Clear();
                            TX = Convert.ToInt32(TXCountPanel.Text);
                            TY = Convert.ToInt32(TYCountPanel.Text);
                            int corX = 0, corY = 0;
                            if (TX <= 256 && TY <= 256 && TX > 0 && TY > 0)
                            {
                                for (short i = 0; i < TX * TY; i++)
                                {
                                    Button button = new Button()
                                    {
                                        Size = new Size(30, 30),
                                        BackColor = Color.White,
                                        Location = new Point(corX, corY),
                                        FlatStyle = FlatStyle.Popup,
                                        Font = new Font("Comic Sans MS", 10),
                                    };
                                    button.Click += (a,e) => {button.Text = TIdPanel.Text;};
                                    PGridPanels.Controls.Add(button);

                                    corX += 30;
                                    if(TX * 30 == corX)
                                    {
                                        corX = 0;
                                        corY += 30;
                                    }
                                }
                            }
                        }
                        else MessageBox.Show("Поля длины и ширины должны быть меньше 256 ячеек\nи больше 0!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else MessageBox.Show("Поля длины и ширины должны содержать только цифры!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else MessageBox.Show("Поля длины и ширины должны быть заполнены!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Что-то пошло не так!\n\n{ex.Message}", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        };

        BSave.Click += (a,e) =>
        {
            if(PGridPanels.Controls.Count > 0)
            {
                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            
                saveFileDialog1.Filter = "txt files (*.txt)|*.txt";
                saveFileDialog1.FilterIndex = 2;
                saveFileDialog1.RestoreDirectory = true;
                saveFileDialog1.FileName = "level.txt";
            
                if(saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    string str = "";
                    int b = 0;
                    for(short i = 0;i < PGridPanels.Controls.Count;i++)
                    {
                        b++;
                        if(PGridPanels.Controls[i].Text.Replace(" ", "") != "") str += PGridPanels.Controls[i].Text + ",";
                        else str += "-1,";
                        if(b == TX)
                        {
                            b = 0;
                            str += "\n";
                        }
                    }

                    StreamWriter stream = new StreamWriter(saveFileDialog1.FileName);
                    stream.Write(str);
                    stream.Close();
                }
            }
            else MessageBox.Show("Сначала вы должны сгенерировать ячейки!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        };
    }
}