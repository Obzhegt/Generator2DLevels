namespace Generator2DLevels;
public class FormCreateLevel : MainForm
{
    public static void Open()
    {
        Form form = new Form();
        form.ClientSize = new Size(300, 200);
        form.Text = "Выбор координат";
        form.BackColor = Color.FromArgb(14,14,14);
        form.StartPosition = FormStartPosition.CenterScreen;
        form.FormBorderStyle = FormBorderStyle.FixedSingle;
        form.MaximizeBox = false;
        form.Icon = new Icon("icon.ico");

        Button BCreate = new Button
        {
            Size = new Size(200, 40),
            BackColor = Color.CadetBlue,
            Text = "Сохранить",
            Location = new Point(50, 150),
            FlatStyle = FlatStyle.Popup,
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
            ForeColor = Color.White,
        };
        form.Controls.Add(BCreate);

        TextBox TXCountPanel = new TextBox
        {
            Text = "2*2",
            Size = new Size(200, 40),
            BackColor = Color.Gray,
            Location = new Point(50, 30),
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
        };
        form.Controls.Add(TXCountPanel);

        TextBox TYCountPanel = new TextBox
        {
            Text = "7*7",
            Size = new Size(200, 40),
            BackColor = Color.Gray,
            Location = new Point(50, 85),
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
        };
        form.Controls.Add(TYCountPanel);

        Label LTextInfo = new Label
        {
            AutoSize = true,
            Text = "X\n\nY",
            Location = new Point(20, 30),
            FlatStyle = FlatStyle.Popup,
            Font = new Font("Comic Sans MS", 16, FontStyle.Bold),
            ForeColor = Color.White,
        };
        form.Controls.Add(LTextInfo);

        form.Show();

        BCreate.Click += (a,e) =>
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "txt files (*.txt)|*.txt";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.FileName = "level.txt";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                int 
                x1 = Convert.ToInt32(TXCountPanel.Text.Split("*")[0]),
                y1 = Convert.ToInt32(TXCountPanel.Text.Split("*")[1]),
                x2 = Convert.ToInt32(TYCountPanel.Text.Split("*")[0]),
                y2 = Convert.ToInt32(TYCountPanel.Text.Split("*")[1]);
                string str = "";

                int b = x1, b2 = y1;
                for(int i = TX * y1 + x1;i < TX * TY;i++)
                {
                    if (PGridPanels.Controls[i].Text.Replace(" ", "") != "") str += PGridPanels.Controls[i].Text + ",";
                    else str += "-1,";
                    if(b == x2)
                    {
                        b2++;
                        i += TX - x2 + x1 - 1;
                        b = x1 - 1;
                        str += "\n";
                        if(b2 == y2 + 1) break;
                    }
                    b++;
                }
                
                StreamWriter stream = new StreamWriter(saveFileDialog1.FileName);
                stream.Write(str, false);
                stream.Close();
            }
        };
    }
}